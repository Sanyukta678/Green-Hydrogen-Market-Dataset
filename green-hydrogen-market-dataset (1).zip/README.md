# Green Hydrogen Market Dataset

This repository contains structured data extracted and organized from the Green Hydrogen Market report.

## Contents
- **market_overview.csv** – Year‑wise market size and growth rate  
- **segmentation.csv** – Market segmentation with percentage share  
- **metadata.json** – Metadata containing source and file info  
- **README.md** – Documentation in GitHub style  

---

### Reference
Original report: https://www.nextmsc.com/report/green-hydrogen-market-ep3583
